define({
  "name": "api",
  "version": "1.0.0",
  "description": "api",
  "title": "api",
  "url": "",
  "header": {
    "title": "接口文档",
    "filename": ""
  },
  "template": {
    "withCompare": true,
    "withGenerator": false
  },
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2020-02-27T10:57:30.445Z",
    "url": "http://apidocjs.com",
    "version": "0.20.0"
  }
});
